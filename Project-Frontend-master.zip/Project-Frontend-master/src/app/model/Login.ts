export class Login{
    id: number;
    username:string;
    password:string;
    mobile:number;
    fullName:String;
    address:String;
    email:String;
    city:String;


    
constructor(){
    this.username='';
    this.password='';
    this.id=0;
    this.mobile=0;
    this.fullName='';
    this.address='';
    this.email='';
    this.city='';
}
}